#pragma once
class PrimitiveRenderer
{
public:
	PrimitiveRenderer();
	~PrimitiveRenderer();
};

