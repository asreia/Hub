#include "PrimitiveRenderer.h"



PrimitiveRenderer::PrimitiveRenderer()
{
}


PrimitiveRenderer::~PrimitiveRenderer()
{
}
