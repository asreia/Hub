#include "PrimitiveActor.h"



PrimitiveActor::PrimitiveActor()
{
}


PrimitiveActor::~PrimitiveActor()
{
}
